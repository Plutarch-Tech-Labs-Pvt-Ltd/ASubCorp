<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Vendor List :</h2>
    <table class="table table-striped">
        <thead>
            <tr>
              <td>ID</td>
              <td>Name</td>
              <td>Email</td>
              <td colspan="2">Action</td>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $vendors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($vendor->id); ?></td>
                <td><?php echo e($vendor->name); ?></td>
                <td><?php echo e($vendor->email); ?></td>
                <td><a href="<?php echo e(route('admin.vendor.view',$vendor->id)); ?>" class="btn btn-info">View Details</a>
                </td>
                <td><a href="<?php echo e(route('admin.vendor.edit',$vendor->id)); ?>" class="btn btn-primary">Edit</a></td>
                <td>
                    <form action="<?php echo e(route('admin.vendor.delete',$vendor->id)); ?>" method="post">
                    <?php echo e(csrf_field()); ?>

                    <input name="_method" type="hidden" value="DELETE">
                    <button class="btn btn-danger" type="submit">Delete</button>
                    </form>
                </td>
            </tr>
      
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php echo e($vendors->links()); ?>

<div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ht1z88f2q4mm/public_html/asubcorp/resources/views/admin/vendor/vendors.blade.php ENDPATH**/ ?>