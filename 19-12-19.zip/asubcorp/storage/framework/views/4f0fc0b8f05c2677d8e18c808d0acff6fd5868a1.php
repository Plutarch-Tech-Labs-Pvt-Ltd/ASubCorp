<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Employee List :</h2>
    <table class="table table-striped">
        <thead>
            <tr>
              <td>ID</td>
              <td>Name</td>
              <td>Email</td>
              <td colspan="3">Action</td>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($employee->id); ?></td>
                <td><?php echo e($employee->name); ?></td>
                <td><?php echo e($employee->email); ?></td>
                <td><a href="<?php echo e(route('admin.employees.view',$employee->user_id)); ?>" class="btn btn-info">View Details</a>
                <td><a href="<?php echo e(route('admin.employees.timesheetview',$employee->user_id)); ?>" class="btn btn-info">View Timesheets</a>
                <td><a href="<?php echo e(route('admin.employees.edit',$employee->id)); ?>" class="btn btn-primary">Edit</a></td>
                <td>
                    <form action="<?php echo e(route('admin.employees.destroy',$employee->id)); ?>" method="post">
                    <?php echo e(csrf_field()); ?>

                    <input name="_method" type="hidden" value="DELETE">
                    <button class="btn btn-danger" type="submit">Delete</button>
                    </form>
                </td>
            </tr>
            
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
     <?php echo e($employees->links()); ?>

<div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ht1z88f2q4mm/public_html/asubcorp/resources/views/admin/employees/employees.blade.php ENDPATH**/ ?>