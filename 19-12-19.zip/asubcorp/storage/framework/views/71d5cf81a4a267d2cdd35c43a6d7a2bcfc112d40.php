<?php $__env->startSection('title','Timesheet Details'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row" style="padding:10px 10px;">
            <div class="col-sm-4">                
                <label>Employee : </label>
                <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <input type="text" value = " <?php echo e($employee->name); ?>" disabled/>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
           
            <div class="col-sm-4">
                <label>Project : </label>
                <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <input type="text" value = " <?php echo e($project->project_name); ?>" disabled/>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div> 
        </div>   
 
        
        <?php $__currentLoopData = $timesheets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $timesheet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="row" style="padding:10px 10px;">        
            <div class="col-sm-4">                
                <label>Start Date : </label>
                <input type="text" value = " <?php echo e($timesheet->start_date); ?>" disabled/>
            </div>
            <div class="col-sm-4">
                <label>End Date : </label>
                <input type="text" value = " <?php echo e($timesheet->end_date); ?>" disabled/>
            </div>
        </div>   
        <div class="row" style="padding:10px 10px;">
            <div class="col-sm-4">                
                <label>Total worked hours : </label>
                <input type="text" value = " <?php echo e($timesheet->worked_hours); ?>" disabled/>
            </div>
            <div class="col-sm-4">
                <label>Leave Hours : </label>
                <input type="text" value = " <?php echo e($timesheet->leave_hours); ?>" disabled/>
            </div>
        </div>   
        <div class="row">
            <div class="col-sm-4">                
                <label>Holiday Hours : </label>
                <input type="text" value = " <?php echo e($timesheet->holiday_hours); ?>" disabled/>
            </div>
            <div class="col-sm-4">
                <label>Submitted Date : </label>
                <input type="text" value = " <?php echo e($timesheet->created_at); ?>" disabled/>
            </div>
        </div>   
<br><br>
        <div class="row">
        <input type="hidden" value = "<?php echo e($timesheet->status); ?>" id = 'status' style="border:none;background-color:#F7F7F7;" disabled/>
        <div class="col-sm-1">
                <form action="<?php echo e(route('approve',$timesheet->id)); ?>" method="post">
                    <?php echo e(csrf_field()); ?>                    
                    <input name="_method" type="hidden" value="POST">
                    <button class="btn btn-primary" id = 'approve' type="submit">Approve</button>
                </form>
            </div>
            <div class="col-sm-1">
                <form action="<?php echo e(route('reject',$timesheet->id)); ?>" method="post">
                    <?php echo e(csrf_field()); ?>                    
                    <input name="_method" type="hidden" value="POST">
                    <button class="btn btn-primary" id = 'reject' type="submit">Reject</button>
                </form>
            </div>
        </div>

        <br><br>
    <div class="row">       
        <div class="col-sm-6">
            <form method="post" action="<?php echo e(route('invoice',$timesheet->id)); ?>" enctype="multipart/form-data" >
                <fieldset>                    
                    <div class="form-group">
                        <input type="hidden" value="<?php echo e(csrf_token()); ?>" name="_token" />
                        <label for="title">Contract Agreement :</label>
                        <input type="file" class="form-control" name="invoice">
                    </div>

                </fieldset>
                <button type="submit" class="btn btn-primary">Upload</button>
            </form>
        </div>
    </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
    </div>

    <script language="javascript">

$(document).ready(function(){
    var input = document.getElementById('status').value;    
  
    if(input == 'submitted')
    {
        document.getElementById("approve").disabled = false;
        document.getElementById("reject").disabled = false;
    }else if(input == 'Approved'){
        document.getElementById("approve").disabled = true;
        document.getElementById("reject").disabled = true;
    }else if(input == 'Rejected'){
        document.getElementById("approve").disabled = true;
        document.getElementById("reject").disabled = true;
    }

    });

    

</script>
        
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app_vendor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\asubcorp2\resources\views/vendor/employees/timesheet_details.blade.php ENDPATH**/ ?>