<?php $__env->startSection('title','Login'); ?>
<?php $__env->startSection('content'); ?>

    <div class="animate form login_form">
        <section class="login_content">
            <form role="form" method="POST" action="<?php echo e(url('/login')); ?>">
                <?php echo e(csrf_field()); ?>

                <h1>Login</h1>
                <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                    <input type="email" class="form-control" name="email" placeholder="email" required="" />
                    <?php if($errors->has('email')): ?>
                        <span class="help-block">
                        <strong><?php echo e($errors->first('email')); ?></strong>
                    </span>
                    <?php endif; ?>
                </div>
                <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                    <input type="password" class="form-control" name="password" placeholder="Password" required="" />
                    <?php if($errors->has('password')): ?>
                        <span class="help-block">
                        <strong><?php echo e($errors->first('password')); ?></strong>
                    </span>
                    <?php endif; ?>
                </div>
                <div>
                    <button class="btn btn-default submit" type="submit">Log in</button>
                    <!--a class="reset_pass" href="<?php echo e(url('/password/reset')); ?>">Lost your password?</a-->
                </div>

                <div class="clearfix"></div>

                <div class="separator">
                    <!--p class="change_link">New to site?
                        <a href="<?php echo e(route('register')); ?>" class="to_register"> Create Account </a>
                    </p-->

                    <div class="clearfix"></div>
                    <br />

                    <div>
                        <h1><i class="fa fa-plus-circle"></i> <?php echo e(config('app.name')); ?></h1>
                        <p>©<?php echo e(date('Y')); ?> </p>
                    </div>
                </div>
            </form>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\asubcorp2\resources\views/auth/login.blade.php ENDPATH**/ ?>