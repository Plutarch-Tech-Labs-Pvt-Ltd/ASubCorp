<?php $__env->startSection('title','Timesheet Details'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row" style="padding:10px 10px;">
            <div class="col-sm-4">                
                <label>Employee : </label>
                <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <input type="text" value = " <?php echo e($employee->name); ?>" disabled/>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
           
            <div class="col-sm-4">
                <label>Project : </label>
                <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <input type="text" value = " <?php echo e($project->project_name); ?>" disabled/>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div> 
        </div>   
 
        
        <?php $__currentLoopData = $timesheets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $timesheet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="row" style="padding:10px 10px;">        
            <div class="col-sm-4">                
                <label>Start Date : </label>
                <input type="text" value = " <?php echo e($timesheet->start_date); ?>" disabled/>
            </div>
            <div class="col-sm-4">
                <label>End Date : </label>
                <input type="text" value = " <?php echo e($timesheet->end_date); ?>" disabled/>
            </div>
        </div>   
        <div class="row" style="padding:10px 10px;">
            <div class="col-sm-4">                
                <label>Total worked hours : </label>
                <input type="text" value = " <?php echo e($timesheet->worked_hours); ?>" disabled/>
            </div>
            <div class="col-sm-4">
                <label>Leave Hours : </label>
                <input type="text" value = " <?php echo e($timesheet->leave_hours); ?>" disabled/>
            </div>
        </div>   
        <div class="row">
            <div class="col-sm-4">                
                <label>Holiday Hours : </label>
                <input type="text" value = " <?php echo e($timesheet->holiday_hours); ?>" disabled/>
            </div>
            <div class="col-sm-4">
                <label>Submitted Date : </label>
                <input type="text" value = " <?php echo e($timesheet->created_at); ?>" disabled/>
            </div>
        </div>  
        
        <br><br>
        
         <div class="row">
              <div class="col-sm-2">                
                <label>Status : </label>
                
            </div>
            <div class="col-sm-2">                
                <label style="color:blue;">Submitted</label>
               <?php if($timesheet->status == "Submitted"): ?>
                <i class="fa fa-check" aria-hidden="true"></i>
               <?php endif; ?>

                
            </div>
            <div class="col-sm-2">
                <label style="color:green;">Approved</label>
                 <?php if($timesheet->status == "Approved"): ?>
                    <i class="fa fa-check" aria-hidden="true"></i>
                <?php endif; ?>
                
            </div>
            <div class="col-sm-2">
                <label style="color:red;">Rejected</labe>
                 <?php if($timesheet->status == "Rejected"): ?>
                    <i class="fa fa-check" aria-hidden="true"></i>
                <?php endif; ?>
            </div>
        </div>   
<br><br>
<?php if($invoice): ?>

    <p><?php echo e($invoice->id); ?></p>
    <a href="<?php echo e(asset('public/uploads/timesheet')); ?>/<?php echo e($invoice->invoice); ?>" download><button class="btn btn-success">Download Invoice</button></a>    
<?php endif; ?>
        <br><br>
    <div class="row">       
        <div class="col-sm-6">
           <a href="<?php echo e(url('/upload/invoice',$timesheet->id)); ?>" class="btn btn-info" accept=".doc,.docx,.pdf,.xlsx">Upload Invoice</a>
        </div>
    </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
    </div>

    <script language="javascript">

$(document).ready(function(){
    var input = document.getElementById('status').value;    
  
    if(input == 'submitted')
    {
        document.getElementById("approve").disabled = false;
        document.getElementById("reject").disabled = false;
    }else if(input == 'Approved'){
        document.getElementById("approve").disabled = true;
        document.getElementById("reject").disabled = true;
    }else if(input == 'Rejected'){
        document.getElementById("approve").disabled = true;
        document.getElementById("reject").disabled = true;
    }

    });

    

</script>
        
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app_vendor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ht1z88f2q4mm/public_html/asubcorp/resources/views/vendor/employees/timesheet_details.blade.php ENDPATH**/ ?>