<?php $__env->startSection('content'); ?>
<div class="container">
<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div><br />
<?php endif; ?>
     <h3>Employee Details : </h3>
        <div class="row">
            <div class="col-sm-2">Name :</div>
            <div class="col-sm-10"><?php echo e($employee[0]->name); ?></div>
        </div>
        <div class="row">
            <div class="col-sm-2">Email :</div>
            <div class="col-sm-10"><?php echo e($employee[0]->email); ?></div>
        </div>
        <div class="row">
            <div class="col-sm-2">Phone :</div>
            <div class="col-sm-10"><?php echo e($employee[0]->phone); ?></div>
        </div>
        
         <div class="row">
            <div class="col-sm-2">Employee Type :</div>
            <div class="col-sm-10"><?php echo e($employee[0]->employee_type); ?></div>
        </div>
        
         <div class="row">
            <div class="col-sm-2">Vendor Name  :</div>
            <div class="col-sm-10"><?php echo e($employee[0]->vendor_id); ?></div>
        </div>
        
         <div class="row">
            <div class="col-sm-2">Project Name :</div>
            <div class="col-sm-10"><?php echo e($employee[0]->project_id); ?></div>
        </div>
        
         <div class="row">
            <div class="col-sm-2">Contract Agreement :</div>
            <div class="col-sm-10"><?php echo e($employee[0]->contract_agreement); ?></div>
        </div>
        
         <div class="row">
            <div class="col-sm-2">Regular Hour :</div>
            <div class="col-sm-10"><?php echo e($employee[0]->regular_hour); ?></div>
        </div>
        
         <div class="row">
            <div class="col-sm-2">Rate Per Hour :</div>
            <div class="col-sm-10"><?php echo e($employee[0]->rate_per_hour); ?></div>
        </div>
        
        <div class="row">
            <div class="col-sm-2">Net Payment Terms :</div>
            <div class="col-sm-10"><?php echo e($employee[0]->net_payment_terms); ?></div>
        </div>
        
        
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\asubcorp2\resources\views/admin/employees/view.blade.php ENDPATH**/ ?>