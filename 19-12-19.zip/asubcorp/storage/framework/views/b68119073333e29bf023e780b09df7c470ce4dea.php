<!-- footer content -->
<!--footer>
    <div class="pull-right">
        <a href="https://colorlib.com"><?php echo e(config('app.name')); ?></a>
    </div>
    <div class="clearfix"></div>
</footer-->
<!-- /footer content --><?php /**PATH /home/ht1z88f2q4mm/public_html/asubcorp/resources/views/partials/_footer.blade.php ENDPATH**/ ?>