<?php $__env->startSection('content'); ?>
<div class="container">
<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div><br />
<?php endif; ?>
    <div class="row">
    <form method="post" action="" >
        <?php echo e(csrf_field()); ?>

        <input name="_method" type="hidden" value="PATCH">
        
        <div class="form-group">
            <input type="hidden" value="<?php echo e(csrf_token()); ?>" name="_token" />
            <label for="title">Employee Name:</label>
            <input type="text" class="form-control" name="employee-name" value="<?php echo e($employee->name); ?>" />
        </div>
        
        <div class="form-group">
            <input type="hidden" value="<?php echo e(csrf_token()); ?>" name="_token" />
            <label for="title">Employee Email:</label>
            <input type="email" class="form-control" name="employee-email" value="<?php echo e($employee->email); ?>" />
        </div>
        
        <div class="form-group">
            <input type="hidden" value="<?php echo e(csrf_token()); ?>" name="_token" />
            <label for="title">Employee Password:</label>
            <input type="text" class="form-control" name="employee-password"/>
        </div>
        <button type="submit" class="btn btn-primary">Update</button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ht1z88f2q4mm/public_html/asubcorp/resources/views/admin/employees/edit.blade.php ENDPATH**/ ?>