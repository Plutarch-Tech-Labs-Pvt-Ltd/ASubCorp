<div class="row top_tiles">
   
    <div class="animated flipInY col-lg-4 col-md-4 col-sm-6 col-xs-12">
        <div class="tile-stats">
            <div class="icon"><i class="fa fa-user"></i></div>
            <div class="count"><?php echo e($vendorCounter); ?></div>
            <h3><a href="#">Vendors</a></h3>
        </div>
    </div>
    
    <div class="animated flipInY col-lg-4 col-md-4 col-sm-6 col-xs-12">
        <div class="tile-stats">
            <div class="icon"><i class="fa fa-user"></i></div>
            <div class="count"><?php echo e($employeeCounter); ?></div>
            <h3><a href="#">Employees</a></h3>
        </div>
    </div>
   
     <div class="animated flipInY col-lg-4 col-md-4 col-sm-6 col-xs-12">
        <div class="tile-stats">
            <div class="icon"><i class="fa fa-list"></i></div>
            <div class="count"><?php echo e($projectCounter); ?></div>
            <h3><a href="#">Projects</a></h3>
        </div>
    </div>
</div><?php /**PATH E:\xampp\htdocs\asubcorp2\resources\views/partials/_toptiles.blade.php ENDPATH**/ ?>