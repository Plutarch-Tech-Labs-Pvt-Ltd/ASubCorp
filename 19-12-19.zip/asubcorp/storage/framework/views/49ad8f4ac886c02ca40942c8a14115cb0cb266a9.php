<?php $__env->startSection('title','Invoice'); ?>


<?php $__env->startSection('content'); ?>
<div class="container">
    
    <div class="row">       
        
             <?php $__currentLoopData = $timesheets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $timesheet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-sm-6">
            <form method="post" action="<?php echo e(route('invoice',$timesheet->id)); ?>" enctype="multipart/form-data" >
                <?php echo csrf_field(); ?>
                <fieldset>      
                 <div class="form-group">
                        <input type="hidden" value="<?php echo e(csrf_token()); ?>" name="_token" />
                        <label for="title">Title :</label>
                        <input type="text" class="form-control" name="title">
                    </div>
                    <div class="form-group">
                        <input type="hidden" value="<?php echo e(csrf_token()); ?>" name="_token" />
                        <label for="title">Invoice :</label>
                        <input type="file" class="form-control" name="invoice">
                    </div>

                </fieldset>
                <button type="submit" class="btn btn-primary" id="upload">Upload</button>
            </form>
        </div>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            
    </div>
<div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app_vendor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ht1z88f2q4mm/public_html/asubcorp/resources/views/vendor/employees/upload_invoice.blade.php ENDPATH**/ ?>