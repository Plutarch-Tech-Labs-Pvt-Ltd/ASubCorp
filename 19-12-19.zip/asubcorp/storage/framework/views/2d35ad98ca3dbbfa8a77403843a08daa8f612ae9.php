<?php $__env->startSection('content'); ?>
<div class="container">
<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div><br />
<?php endif; ?>
     <h3>Vendor Details : </h3>
        <div class="row">
            <div class="col-sm-2">Name :</div>
            <div class="col-sm-10"><?php echo e($vendor[0]->name); ?></div>
        </div>
        <div class="row">
            <div class="col-sm-2">Email :</div>
            <div class="col-sm-10"><?php echo e($vendor[0]->email); ?></div>
        </div>
        <div class="row">
            <div class="col-sm-2">Phone :</div>
            <div class="col-sm-10"><?php echo e($vendor[0]->phone); ?></div>
        </div>
        <div class="row">
            <div class="col-sm-2">Company Name :</div>
            <div class="col-sm-10"><?php echo e($vendor[0]->company_name); ?></div>
        </div>
        <div class="row">
            <div class="col-sm-2">Company Url :</div>
            <div class="col-sm-10"><?php echo e($vendor[0]->company_url); ?></div>
        </div>
        
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ht1z88f2q4mm/public_html/asubcorp/resources/views/admin/vendor/view.blade.php ENDPATH**/ ?>