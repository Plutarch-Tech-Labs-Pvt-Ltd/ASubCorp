<div class="col-md-3 left_col">
    <div class="left_col scroll-view">
        <div class="navbar nav_title" style="border: 0;">
            <a href="<?php echo e(url('/')); ?>" class="site_title"><i class="fa fa-paw"></i> <span><?php echo e(config('app.name')); ?></span></a>
        </div>

        <div class="clearfix"></div>

        <!-- menu profile quick info -->
        <div class="profile">
            <div class="profile_pic">
                <img src="/images/img.jpg" alt="..." class="img-circle profile_img">
            </div>
            <div class="profile_info">
                <span>Welcome,</span>
                <h2><?php echo e(auth()->user()->name); ?></h2>
            </div>
        </div>
        <!-- /menu profile quick info -->

        <br />

        <!-- sidebar menu -->
        <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
            <div class="menu_section">
                <h3>General</h3>
                <ul class="nav side-menu">
                    <li><a href="<?php echo e(route('employee.dashboard')); ?>"><i class="fa fa-home"></i> Dashboard</a></li>
                    
                    <li><a><i class="fa fa-users"></i>Timesheets <span class="fa fa-chevron-down"></span></a>
                        <ul class="nav child_menu">
                            <li><a href="<?php echo e(url('/alltimesheets',auth()->user()->id)); ?>">All Timesheets</a></li>
                            <li><a href="<?php echo e(route('create_timesheet',auth()->user()->id)); ?>">Create Timesheets</a></li>
                        </ul>   
                    </li>
                    
                </ul>
            </div>

        </div>
        <!-- /sidebar menu -->

        <?php echo $__env->make('partials._sidenav_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div><?php /**PATH /home/ht1z88f2q4mm/public_html/asubcorp/resources/views/partials/_employee_sidenav.blade.php ENDPATH**/ ?>