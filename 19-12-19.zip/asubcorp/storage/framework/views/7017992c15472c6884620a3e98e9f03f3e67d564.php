<?php $__env->startSection('title','All Timesheets'); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Timesheets List :</h2>
    <table class="table table-striped">
        <thead>
            <tr>
              <td>From Date</td>
              <td>To Date</td>
              <td>Submitted Date</td>
              <td>Status</td>
              <td></td>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $timesheets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $timesheet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($timesheet->start_date); ?></td>
                <td><?php echo e($timesheet->end_date); ?></td>
                <td><?php echo e($timesheet->created_at); ?></td> 
                <td><?php echo e($timesheet->status); ?></td>
                <td><a href="<?php echo e(route('timesheet_details',$timesheet->id)); ?>" class="btn btn-primary">View</a></td>              
                
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app_employee', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\asubcorp2\resources\views/employee/all_timesheets.blade.php ENDPATH**/ ?>