<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta name="robots" content="noindex, nofollow">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name','Laravel Gentelella')); ?> | <?php echo $__env->yieldContent('title'); ?> </title>

    <!-- App Css -->
    <link href="<?php echo e(URL::asset('public/css/app.css')); ?>" rel="stylesheet">
    
    <!-- Jquery -->
      
    <link rel="stylesheet" href="http://ajax.googleapis.com/ajax/libs/jqueryui/1.10.4/themes/smoothness/jquery-ui.css" />

    <?php echo $__env->yieldPushContent('header-scripts'); ?>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

     
   
    

</head><?php /**PATH /home/ht1z88f2q4mm/public_html/asubcorp/resources/views/partials/_head.blade.php ENDPATH**/ ?>