<!-- footer content -->
<!--footer>
    <div class="pull-right">
        <a href="https://colorlib.com"><?php echo e(config('app.name')); ?></a>
    </div>
    <div class="clearfix"></div>
</footer-->
<!-- /footer content --><?php /**PATH E:\xampp\htdocs\asubcorp2\resources\views/partials/_footer.blade.php ENDPATH**/ ?>