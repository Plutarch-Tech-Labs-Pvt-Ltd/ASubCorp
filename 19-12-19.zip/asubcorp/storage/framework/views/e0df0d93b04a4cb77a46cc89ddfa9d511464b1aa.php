<?php $__env->startSection('title','Timesheet Details'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row" style="padding:10px 10px;">
            <div class="col-sm-4">                
                <label>Vendor : </label>
                <?php $__currentLoopData = $vendors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <input type="text" value = " <?php echo e($vendor->name); ?>" disabled/>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
           
            <div class="col-sm-4">
                <label>Project : </label>
                <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <input type="text" value = " <?php echo e($project->project_name); ?>" disabled/>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
           
        </div>   
        <?php $__currentLoopData = $timesheets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $timesheet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="row" style="padding:10px 10px;">
            <div class="col-sm-4">                
                <label>Start Date : </label>
                <input type="text" value = " <?php echo e($timesheet->start_date); ?>" disabled/>
            </div>
            <div class="col-sm-4">
                <label>End Date : </label>
                <input type="text" value = " <?php echo e($timesheet->end_date); ?>" disabled/>
            </div>
        </div>   
        <div class="row" style="padding:10px 10px;">
            <div class="col-sm-4">                
                <label>Total worked hours : </label>
                <input type="text" value = " <?php echo e($timesheet->worked_hours); ?>" disabled/>
            </div>
            <div class="col-sm-4">
                <label>Leave Hours : </label>
                <input type="text" value = " <?php echo e($timesheet->leave_hours); ?>" disabled/>
            </div>
        </div>   
        <div class="row">
            <div class="col-sm-4">                
                <label>Holiday Hours : </label>
                <input type="text" value = " <?php echo e($timesheet->holiday_hours); ?>" disabled/>
            </div>
            <div class="col-sm-4">
                <label>Submitted Date : </label>
                <input type="text" value = " <?php echo e($timesheet->created_at); ?>" disabled/>
            </div>
        </div>   
        <br><br>
        
         <div class="row">
              <div class="col-sm-2">                
                <label>Status : </label>
                
            </div>
            <div class="col-sm-2">                
                <label style="color:blue;">Submitted</label>
               <?php if($timesheet->status == "submitted"): ?>
                <i class="fa fa-check" aria-hidden="true"></i>
               <?php endif; ?>

                
            </div>
            <div class="col-sm-2">
                <label style="color:green;">Approved</label>
                 <?php if($timesheet->status == "Approved"): ?>
                    <i class="fa fa-check" aria-hidden="true"></i>
                <?php endif; ?>
                
            </div>
            <div class="col-sm-2">
                <label style="color:red;">Rejected</labe>
                 <?php if($timesheet->status == "Rejected"): ?>
                    <i class="fa fa-check" aria-hidden="true"></i>
                <?php endif; ?>
            </div>
        </div> 
        
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app_employee', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ht1z88f2q4mm/public_html/asubcorp/resources/views/employee/timesheet_details.blade.php ENDPATH**/ ?>