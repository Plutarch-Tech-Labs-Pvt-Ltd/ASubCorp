<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Project List :</h2>
    <table class="table table-striped">
        <thead>
            <tr>
              <td>ID</td>
              <td>Project Name</td>
              <td>Project Client</td>
              <td>Project Start Date</td>
              <td colspan="2">Action</td>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($project->id); ?></td>
                <td><?php echo e($project->project_name); ?></td>
                <td><?php echo e($project->client_name); ?></td>
                <td><?php echo e($project->start_date); ?></td>
                <td><a href="<?php echo e(route('admin.project.edit',$project->id)); ?>" class="btn btn-primary">Edit</a></td>
                <td>
                    <form action="<?php echo e(route('admin.project.delete',$project->id)); ?>" method="post">
                    <?php echo e(csrf_field()); ?>

                    <input name="_method" type="hidden" value="DELETE">
                    <button class="btn btn-danger" type="submit">Delete</button>
                    </form>
                </td>
            </tr>
      
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php echo e($projects->links()); ?>

<div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ht1z88f2q4mm/public_html/asubcorp/resources/views/admin/project/projects.blade.php ENDPATH**/ ?>