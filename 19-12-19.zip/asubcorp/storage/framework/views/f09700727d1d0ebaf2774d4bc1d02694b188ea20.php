<!DOCTYPE html>
<html lang="en">
<?php echo $__env->make('partials._head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<body class="nav-md" >
<div class="container body">

    <div class="main_container">

    
    <?php echo $__env->make('partials._employee_sidenav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    

    <!-- top navigation -->
    <?php echo $__env->make('partials._topnav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- /top navigation -->

        <!-- page content -->
        <div class="right_col" role="main" >
            <div class="page-title">
                <div class="title_left">
                    <h3><?php echo $__env->yieldContent('title'); ?></h3>
                </div>
            </div>
            <div class="clearfix"></div><br><br>
            <div class="data-pjax">
                <?php echo $__env->yieldContent('content'); ?>

            </div>
        </div>
        <!-- /page content -->

        <!-- footer content -->
    <?php echo $__env->make('partials._footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- /footer content -->
    </div>
</div>



<script src="<?php echo e(asset('public/js/app.js')); ?>"></script>

<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<script src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.10.4/jquery-ui.min.js"></script>
<?php echo $__env->make('partials._notification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldPushContent('scripts'); ?>


</body>
</html><?php /**PATH /home/ht1z88f2q4mm/public_html/asubcorp/resources/views/layouts/app_employee.blade.php ENDPATH**/ ?>