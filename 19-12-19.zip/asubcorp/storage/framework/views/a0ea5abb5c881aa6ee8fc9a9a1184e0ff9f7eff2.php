<!DOCTYPE html>
<html lang="en">
<?php echo $__env->make('partials._head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body class="nav-md" >
<div class="container body">

    <div class="main_container">

    
    <?php echo $__env->make('partials._vendor_sidenav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    

    <!-- top navigation -->
    <?php echo $__env->make('partials._topnav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- /top navigation -->

        <!-- page content -->
        <div class="right_col" role="main" >
            <div class="page-title">
                <div class="title_left">
                    <h3><?php echo $__env->yieldContent('title'); ?></h3>
                </div>

                <div class="title_right">
                    <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                        <div class="input-group">
                            <input type="text" class="form-control" placeholder="Search for...">
                            <span class="input-group-btn">
                      <button class="btn btn-default" type="button">Go!</button>
                    </span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="clearfix"></div>
            <div class="data-pjax">
                <?php echo $__env->yieldContent('content'); ?>

            </div>
        </div>
        <!-- /page content -->

        <!-- footer content -->
    <?php echo $__env->make('partials._footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- /footer content -->
    </div>
</div>



<script src="<?php echo e(asset('js/app.js')); ?>"></script>
<?php echo $__env->make('partials._notification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldPushContent('scripts'); ?>


</body>
</html><?php /**PATH E:\xampp\htdocs\asubcorp2\resources\views/layouts/app_vendor.blade.php ENDPATH**/ ?>