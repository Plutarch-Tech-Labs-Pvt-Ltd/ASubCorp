<?php $__env->startSection('content'); ?>
<div class="container">
<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div><br />
<?php endif; ?>
    <div class="row">
    <form method="post" action="<?php echo e(url('/create/project')); ?>">
        <fieldset>
        <legend>Project Details : </legend>
        
        <div class="form-group">
            <input type="hidden" value="<?php echo e(csrf_token()); ?>" name="_token" />
            <label for="title">Project Name:</label>
            <input type="text" class="form-control" name="project-name"/>
        </div>
        
        <div class="form-group">
            <input type="hidden" value="<?php echo e(csrf_token()); ?>" name="_token" />
            <label for="title">Project Client:</label>
            <input type="text" class="form-control" name="project-client"/>
        </div>
        
        <div class="form-group">
            <input type="hidden" value="<?php echo e(csrf_token()); ?>" name="_token" />
            <label for="title">Project Start Date:</label>
            <input type="date" class="form-control" name="project-startdate"/>
        </div>

        </fieldset>
      
         
        <button type="submit" class="btn btn-primary">Create</button>
        </form>
        
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\asubcorp2\resources\views/admin/project/create.blade.php ENDPATH**/ ?>