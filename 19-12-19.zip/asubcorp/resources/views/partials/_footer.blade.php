<!-- footer content -->
<!--footer>
    <div class="pull-right">
        <a href="https://colorlib.com">{{config('app.name')}}</a>
    </div>
    <div class="clearfix"></div>
</footer-->
<!-- /footer content -->