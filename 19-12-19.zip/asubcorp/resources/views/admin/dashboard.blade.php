@extends('layouts.app')
@section('title','Dashboard')
@section('content')
    @include('partials._toptiles')
@endsection